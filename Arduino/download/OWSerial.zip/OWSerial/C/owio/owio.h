#include <stdio.h>
extern void owio_start(void);
extern void owio_stop(void);
